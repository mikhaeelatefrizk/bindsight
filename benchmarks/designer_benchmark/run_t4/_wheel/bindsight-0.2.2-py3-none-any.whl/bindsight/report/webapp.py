# SPDX-FileCopyrightText: 2026 Mikhaeel Atef Rizk Wahba
# SPDX-License-Identifier: AGPL-3.0-or-later
"""bindsight web app — multi-page Streamlit interface.

Anyone can run this locally (``bindsight ui``) or hit the Hugging Face Space
deployment to use the tool entirely in a browser.

Pages:

- **Home** — what this is, why it matters, the headline results, CTAs
- **Real results** — the committed benchmarks: rediscovery over six TCGA
  cohorts, and the 20 real ERBB2 binders with their predicted complexes
- **Demo** — one-click run on a real TCGA-BRCA cohort
- **Run with my data** — upload counts.tsv + design.tsv, run the pipeline
- **Browse a run** — open a run directory, inspect tables, view the report
- **About** — links to docs, source, citation

The app is intentionally one file so a hosted Streamlit runtime can deploy from a single
import path. Styling and brand constants come from
:mod:`bindsight.report.theme`; the published numbers come from
:mod:`bindsight.report.showcase`, so nothing on screen is hand-typed.
"""

from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from bindsight.report import showcase, theme

if TYPE_CHECKING:  # pragma: no cover - typing only; runtime imports stay lazy
    from bindsight.config import RunConfig

# Streamlit must be importable as the entry point. The rest is lazy-loaded
# below so command-line flags + module probing work without it.
try:
    import streamlit as st
except ImportError:  # pragma: no cover
    st = None  # type: ignore[assignment]


#: ``st.session_state`` keys. The app previously used no session state at all,
#: so demo and user-run results were rendered inside the ``if st.button(...)``
#: block and vanished the moment any other widget was touched.
_NAV_KEY = "bs_nav"
#: Streamlit forbids assigning to a widget's own key once that widget has been
#: instantiated this run, so cross-page buttons record their intent here and
#: ``main()`` applies it before building the navigation radio.
_NAV_PENDING_KEY = "bs_nav_pending"
_DEMO_RESULT_KEY = "bs_demo_result"
_RUN_RESULT_KEY = "bs_run_result"


def _inject_css() -> None:
    """Apply the shared stylesheet from :mod:`bindsight.report.theme`."""
    st.markdown(theme.app_css(), unsafe_allow_html=True)


def _under_app_test() -> bool:
    """True when running inside Streamlit's ``AppTest`` harness.

    ``AppTest`` (1.60 and 1.61 alike) has a nondeterministic internal bug when an
    ``st.iframe`` is in the render tree: ``run()`` indexes
    ``event_data[-1]["client_state"]`` assuming the last script event is
    ``SHUTDOWN``, but an iframe reorders the event stream so that key can be
    absent → ``KeyError('client_state')``, which flakes the smoke tests on some
    CI runners. The iframe also cannot do anything useful without a browser to
    execute its JavaScript, so the app skips it under the harness.

    The signal is the harness's import footprint: the deployed app is launched
    with ``streamlit run`` and never imports ``streamlit.testing``, so its
    presence in ``sys.modules`` reliably and side-effect-free marks a test run.
    """
    return "streamlit.testing" in sys.modules


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------
#: The pipeline, as a visitor should read it. ``gpu`` marks the stages that
#: are offloaded rather than run in the browser.
_PIPELINE_STAGES: tuple[tuple[str, str, bool], ...] = (
    ("Patient RNA-seq", "counts + design", False),
    ("Differential expression", "pydeseq2", False),
    ("Cell-surface filter", "SURFY surfaceome", False),
    ("Safety + tractability", "GTEx · Open Targets", False),
    ("Targetable site", "SURFACE-Bind · AlphaFold", False),
    ("Binder design", "RFdiffusion + MPNN", True),
    ("Structure + affinity", "Boltz-2", True),
    ("Ranked candidates", "multi-objective", False),
    ("Provenance", "PROV-O · RO-Crate", False),
)


def _goto(page: str) -> None:
    """Request a switch to ``page`` on the next run, then rerun."""
    st.session_state[_NAV_PENDING_KEY] = page
    st.rerun()


def _page_home() -> None:
    from bindsight import __version__

    st.markdown(
        f"""
        <div class="bs-hero">
          <h1>bindsight</h1>
          <p>{theme.TAGLINE}</p>
          <div class="bs-hero-sub">
            Genomics stops at &ldquo;here are the interesting genes&rdquo;.
            Protein design starts at &ldquo;given a target structure&rdquo;.
            bindsight is the open, citable bridge between them.
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Plain-English on-ramp for a non-specialist visitor, before any jargon.
    # Single-sourced with the docs site via theme.PLAIN_SUMMARY.
    st.info(theme.PLAIN_SUMMARY, icon="💡")
    st.caption("New to the terms below? See the **📖 Glossary** in the sidebar.")

    # Headline numbers come from benchmarks/ via showcase.py -- never typed in,
    # so this page cannot claim more than the committed results support.
    stats = showcase.headline_stats()
    if stats:
        st.markdown(
            '<div class="bs-stats">'
            + "".join(
                f'<div class="bs-stat"><div class="v">{s.value}</div>'
                f'<div class="k">{s.label}</div>'
                f'<div class="small-muted">{s.detail}</div></div>'
                for s in stats
            )
            + "</div>",
            unsafe_allow_html=True,
        )

    cta = st.columns(3)
    if cta[0].button("🔬  Explore real results", type="primary", width="stretch"):
        _goto("🔬 Real results")
    if cta[1].button("✨  Run the live demo", width="stretch"):
        _goto("✨ Demo")
    if cta[2].button("📤  Use my own data", width="stretch"):
        _goto("📤 Run on my data")

    st.markdown("## How it works")
    st.markdown(
        '<div class="bs-flow">'
        + "".join(
            f'<div class="s{" gpu" if gpu else ""}">{name}<small>{tool}</small></div>'
            for name, tool, gpu in _PIPELINE_STAGES
        )
        + "</div>",
        unsafe_allow_html=True,
    )
    st.caption(
        "Amber stages need a GPU and are offloaded to Colab, Kaggle, Modal or your own "
        "Docker host — everything else runs on a CPU laptop, and in this browser."
    )

    with st.expander("What each step means, in plain English"):
        st.markdown(
            "1. **Patient RNA-seq** — start from a tumour's gene-activity readout.\n"
            "2. **Differential expression** — find the genes far more active in tumour "
            "than in healthy tissue.\n"
            "3. **Cell-surface filter** — keep only proteins that sit on the cell "
            "surface, where a drug could reach them.\n"
            "4. **Safety + tractability** — drop targets also common in vital healthy "
            "organs, and keep ones known to be druggable.\n"
            "5. **Targetable site** — pick the exact spot on the target's 3-D structure "
            "to aim a binder at.\n"
            "6. **Binder design** — invent small proteins shaped to grip that spot "
            "(AI: RFdiffusion + ProteinMPNN).\n"
            "7. **Structure + affinity** — predict the binder-and-target complex to "
            "check it would actually stick (AI: Boltz-2).\n"
            "8. **Ranked candidates** — score and order the designs by how good and how "
            "makeable they are.\n"
            "9. **Provenance** — save a complete, reproducible record of every input and "
            "step behind each result.\n\n"
            "Every term here is defined on the **📖 Glossary** page."
        )

    col_left, col_right = st.columns([3, 2])
    with col_left:
        st.markdown(
            "### What this is\n"
            'Going from "this gene is up in disease" to "here is a designed '
            'binder candidate" used to take a competent grad student 4–6 weeks of '
            "glue scripting. bindsight does it in a single command on a CPU laptop, "
            "with reproducibility that survives peer review.\n\n"
            "Every ranked candidate stays one click from its evidence — the patient "
            "cohort, the differential expression, the structure, the trajectory seed, "
            "the validator metrics."
        )
        st.markdown("### Three commands cover the whole pipeline")
        st.code(
            "bindsight demo                                # guided demo, real TCGA cohort\n"
            "bindsight run my_config.yaml --out runs/x     # your cohort end-to-end\n"
            "bindsight ui                                  # this web interface, locally",
            language="bash",
        )

    with col_right:
        st.markdown("### What works today")
        st.markdown(
            '<div style="line-height:1.9">'
            '<span class="pill ok-pill">✓</span> Differential expression (pydeseq2)<br>'
            '<span class="pill ok-pill">✓</span> Surfaceome filter (SURFY)<br>'
            '<span class="pill ok-pill">✓</span> Open Targets enrichment<br>'
            '<span class="pill ok-pill">✓</span> AlphaFoldDB structure pull<br>'
            '<span class="pill ok-pill">✓</span> SURFACE-Bind site lookup<br>'
            '<span class="pill ok-pill">✓</span> Multi-objective ranking<br>'
            '<span class="pill ok-pill">✓</span> Paper-style HTML report<br>'
            '<span class="pill ok-pill">✓</span> RO-Crate export (Zenodo-ready)<br>'
            '<span class="pill ok-pill">✓</span> GPU cost estimator<br>'
            '<span class="pill warn-pill">≈</span> RFdiffusion + ProteinMPNN + Boltz-2 '
            "(GPU, offloaded)<br>"
            "</div>",
            unsafe_allow_html=True,
        )
        st.markdown(
            f'<div style="margin-top:1rem">'
            f'<span class="pill ok-pill">v{__version__}</span>'
            f'<span class="pill">{theme.LICENSE_NAME}</span>'
            f'<span class="pill">CPU-friendly</span>'
            f"</div>",
            unsafe_allow_html=True,
        )

    st.markdown(
        "### Who this is for\n\n"
        "- **Translational researchers** with a TCGA cohort and limited compute\n"
        "- **Clinical biologists** who need a defensible audit trail (PROV-O / RO-Crate)\n"
        "- **Method developers** benchmarking new designers/validators against a fixed upstream\n"
        "- **Pharma early-discovery teams** wanting an open, reproducible comparator"
    )


def _demo_config(out_dir: Path) -> RunConfig:
    """Build the demo run configuration.

    Split out from :func:`_run_demo_cached` so the path handling is testable
    without executing the pipeline.

    The cohort is cached under the OS user-cache directory, exactly as
    ``bindsight demo`` does (``cli.py``), rather than beside the bundled
    ``examples/demo/config.yaml``. Three reasons:

    1. ``examples/demo/counts.tsv`` does not exist and is asserted absent by
       ``tests/test_demo_e2e.py``, so the previous paths could only ever
       trigger a fresh download.
    2. That download landed *inside the install tree*, which is read-only in
       the Docker image behind the Hugging Face Space.
    3. Sharing the CLI's cache means whichever runs first warms the other.

    The file is ``counts.tsv.gz``; pandas infers compression from the
    extension, so the name has to match what the GDC fetcher writes.

    Args:
        out_dir: Directory the run should write into.

    Returns:
        A ready-to-run :class:`bindsight.config.RunConfig`.
    """
    from bindsight.config import RunConfig
    from bindsight.io.paths import cache_dir

    cfg_path = _find_repo_root() / "examples" / "demo" / "config.yaml"
    if not cfg_path.is_file():
        # A bare ``pip install bindsight`` does not ship examples/; the Demo page
        # only works from a source checkout, which the hosted Space uses.
        # Raise a legible message rather than letting ``from_yaml`` surface a
        # bare FileNotFoundError as a traceback on the page.
        raise FileNotFoundError(
            f"The bundled demo configuration was not found at {cfg_path}. The Demo "
            "page needs the full source checkout — it ships with the hosted "
            "Hugging Face Space deployment, but a plain "
            "'pip install bindsight' does not include it. Run `bindsight demo` "
            "from a repository clone, or use the hosted demo."
        )
    cfg = RunConfig.from_yaml(cfg_path)
    cfg.out_dir = out_dir

    cohort_dir = cache_dir("gdc") / "tcga_brca"
    cfg.inputs.counts = cohort_dir / "counts.tsv.gz"
    cfg.inputs.design = cohort_dir / "design.tsv"
    return cfg


def _run_demo_cached() -> tuple[Path, object, float, Path]:
    """Run the demo pipeline once per server process and cache the full result.

    The demo always uses the same real TCGA-BRCA cohort (deterministic by GDC
    file id), so the output is safe to share across visitors. Caching the run
    means only the first visitor on a fresh container pays the
    download + pydeseq2 + Open Targets + AlphaFoldDB cost; every subsequent
    visitor sees the same result instantly, and the per-visitor RAM spike → ~0.
    This is the difference between "the app crashes after the first demo" and
    "the app stays up indefinitely under heavy load".
    """
    from bindsight.pipelines import discover as discover_pipeline
    from bindsight.report import render_run

    out_dir = Path(tempfile.mkdtemp(prefix="bindsight_demo_")) / "demo_run"
    cfg = _demo_config(out_dir)

    t0 = time.time()
    manifest = discover_pipeline.run(cfg, out_dir=out_dir)
    elapsed = time.time() - t0
    report_path = render_run(out_dir)
    return out_dir, manifest, elapsed, report_path


def _load_parquet_cached(path_str: str) -> Any:
    """Cached parquet read so revisiting a run page doesn't re-read from disk."""
    import pandas as pd

    p = Path(path_str)
    if not p.exists():
        return None
    return pd.read_parquet(p)


# Apply Streamlit caching decorators only if streamlit is available.  The
# module must remain importable in test environments where streamlit isn't
# installed (see tests/test_package_imports.py), so we wrap rather than
# decorate at the def site.
if st is not None:
    _run_demo_cached = st.cache_resource(show_spinner=False)(_run_demo_cached)
    _load_parquet_cached = st.cache_data(show_spinner=False)(_load_parquet_cached)


def _manifest_stages(manifest: Any) -> list[Any]:
    """Return the stage records of ``manifest``, whatever shape it arrives in.

    A live run hands us a :class:`~bindsight.provenance.manifest.RunManifest`
    object; the Browse page reads ``run_manifest.jsonld`` back from disk and so
    holds plain dicts. Both have to reach the failed-stage guard.
    """
    stages = (
        manifest.get("stages") if isinstance(manifest, dict) else getattr(manifest, "stages", None)
    )
    return list(stages) if isinstance(stages, list) else []


def _stage_field(stage: Any, field: str) -> Any:
    """Read ``field`` off a stage record held as either an object or a dict."""
    if isinstance(stage, dict):
        return stage.get(field)
    return getattr(stage, field, None)


def _stage_failures(manifest: Any) -> list[tuple[str, str | None]]:
    """Return ``(stage_name, error)`` for every stage that did not complete.

    A ``skipped_cache`` stage is a success (its output already existed), so only
    ``failed`` stages count. Returns ``[]`` when the manifest is ``None`` or all
    stages completed.
    """
    failures: list[tuple[str, str | None]] = []
    for s in _manifest_stages(manifest):
        if _stage_field(s, "status") != "failed":
            continue
        error = _stage_field(s, "error")
        failures.append(
            (str(_stage_field(s, "name") or "?"), None if error is None else str(error))
        )
    return failures


def _load_run_manifest(run_dir: Path) -> dict[str, Any] | None:
    """Read a run directory's provenance manifest from disk.

    Args:
        run_dir: Directory produced by any bindsight front-end.

    Returns:
        The parsed manifest, or ``None`` when it is absent or unreadable.
        ``None`` means *provenance unknown*, not *nothing failed*, so callers
        must say so rather than presenting the run as verified.
    """
    path = run_dir / "run_manifest.jsonld"
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def _render_stage_failures(manifest: Any) -> bool:
    """Show a friendly error if any pipeline stage failed; return ``True`` if so.

    This is the guard that stops a *broken* run from being presented as a
    *successful, empty* one — the difference between "this cohort has no
    surface-antigen candidates" (a real finding) and "the differential-expression
    step crashed" (no finding at all). Conflating the two could let a scientist
    read a failed run as a genuine negative result, so a failed stage must never
    render as success.
    """
    failures = _stage_failures(manifest)
    if not failures:
        return False
    names = ", ".join(name for name, _ in failures)
    plural = "s" if len(failures) > 1 else ""
    st.error(
        f"The pipeline did not finish: the **{names}** stage{plural} failed. "
        "These results are incomplete and must not be read as a real "
        "(negative) finding.",
        icon="🛑",
    )
    with st.expander("Technical details"):
        for name, err in failures:
            st.markdown(f"**{name}**")
            st.code(err or "no error detail recorded", language="text")
    return True


def _render_pipeline_error(exc: Exception, *, context: str) -> None:
    """Render an uncaught pipeline exception as a calm, actionable message.

    The raw traceback is tucked behind an expander so a non-technical visitor
    sees a sentence, not a stack dump — but a developer can still open it.
    """
    intro = {
        "demo": "The demo could not run just now.",
        "run": "The pipeline could not run on your data.",
    }.get(context, "The pipeline could not run.")
    hint = ""
    if context == "demo":
        hint = (
            " This usually means the TCGA data source (NIH/GDC) was slow or "
            "temporarily unreachable — please try again in a moment."
        )
    st.error(f"{intro}{hint}\n\n**Details:** {exc}", icon="⚠️")
    with st.expander("Technical details"):
        st.exception(exc)


def _page_demo() -> None:
    st.title("Demo: real TCGA-BRCA discovery")
    st.markdown(
        "This runs the full discovery half against a **real TCGA breast-cancer "
        "cohort** (NIH/GDC, tumor vs. adjacent normal). Real pydeseq2 differential "
        "expression, the full SURFY surfaceome filter, Open Targets enrichment, and "
        "ranked output — with full provenance. GPU not required.\n\n"
        "**Result:** antibody-tractable cell-surface antigens over-expressed in "
        "tumor; well-known targets such as ERBB2 (HER2) appear among the candidates "
        "when their signal is present in the cohort."
    )

    if st.button("▶  Run demo now", type="primary", width="stretch"):
        # The pipeline result is cached per server process via
        # @st.cache_resource, so only the first visitor pays the cold-run cost.
        # cache_resource does not cache exceptions, so a transient GDC failure
        # can be retried simply by clicking again.
        with st.spinner("Running demo pipeline (cached after first run)…"):
            try:
                out_dir, manifest, elapsed, report_path = _run_demo_cached()
            except Exception as e:  # surface anything as a calm message
                _render_pipeline_error(e, context="demo")
                return
        # Stash it so the result survives any later widget interaction.
        st.session_state[_DEMO_RESULT_KEY] = (out_dir, manifest, elapsed, report_path)

    stashed = st.session_state.get(_DEMO_RESULT_KEY)
    if stashed is not None:
        out_dir, manifest, elapsed, report_path = stashed
        if _render_stage_failures(manifest):
            return
        st.success(f"Demo complete in {elapsed:.1f} seconds.")
        _show_run_summary(out_dir, manifest, report_path)


def _render_complex(cif_path: Path, height: int = 420) -> bool:
    """Render a predicted binder-target complex with py3Dmol.

    ``py3Dmol`` has been a declared dependency of the ``report`` extra since the
    beginning and was never imported anywhere; ``report/html.py`` even documents
    a structure viewer that did not exist. This is that viewer.

    Chain ``B`` is the designed binder, chain ``T`` the target antigen, so the
    colouring shows the actual designed interface rather than a generic ribbon.

    Args:
        cif_path: Path to a validator-produced complex mmCIF.
        height: Viewer height in pixels.

    Returns:
        ``True`` if the viewer was rendered, ``False`` if py3Dmol is unavailable.
    """
    try:
        import py3Dmol
    except ImportError:  # pragma: no cover - report extra always ships py3Dmol
        st.info("Install the `report` extra to view structures: `pip install -e '.[report]'`")
        return False

    if _under_app_test():  # pragma: no cover - exercised only under AppTest
        # The JS viewer needs a browser the harness doesn't have, and its iframe
        # trips a nondeterministic AppTest bug (see _under_app_test). The
        # deployed app takes the real path below.
        return True

    view = py3Dmol.view(width="100%", height=height)
    view.addModel(cif_path.read_text(encoding="utf-8"), "cif")
    view.setStyle({"chain": "T"}, {"cartoon": {"color": theme.NAVY, "opacity": 0.85}})
    view.setStyle({"chain": "B"}, {"cartoon": {"color": theme.ACCENT}})
    view.zoomTo()
    # st.iframe auto-detects the HTML string and embeds it in a JS-capable iframe
    # (py3Dmol needs script execution); it supersedes the deprecated
    # components.v1.html. The HTML is generated by py3Dmol, not user input.
    st.iframe(view._make_html(), height=height + 10)
    return True


def _page_results() -> None:
    """Show the real, committed benchmark results."""
    import pandas as pd

    st.title("Real results")
    st.markdown(
        "Everything on this page is read straight from `benchmarks/` in the "
        "repository — the same files the paper and the README cite. Nothing here "
        "is illustrative, recomputed on the fly, or hand-typed."
    )

    study = showcase.load_study()
    designer = showcase.load_designer_benchmark()

    if study is None and designer is None:
        st.warning(
            "The `benchmarks/` tree isn't available in this install — it ships with "
            "the repository, not the wheel."
        )
        st.markdown(
            f"Browse the committed results on [GitHub]({theme.GITHUB_URL}/tree/main/benchmarks)."
        )
        return

    # -- Rediscovery ------------------------------------------------------
    if study is not None:
        st.markdown("## Does it rediscover antigens we already trust?")
        st.markdown(
            f"**{study.n_scored} antigen-cohort pairs across {study.n_projects} real TCGA "
            "projects.** Each cohort is a *whole, unstratified* project — every primary "
            "tumour against every solid-tissue normal — with the contrast paired on the "
            "patient. Nothing selects for the antigen being sought."
        )
        st.markdown(
            "That matters because the earlier version of this study did select for it: "
            "it picked breast tumours by a subtype classifier built on fifty genes, one "
            "of which is ERBB2, and then reported discovering ERBB2. The headline below "
            "is far weaker than that one, and it is the honest number."
        )

        top = study.headline
        cols = st.columns(4)
        if top is not None:
            cols[0].metric(
                f"{top['symbol']} rank",
                f"{top['rank']} of {top['shortlist_size']}",
                help=str(top.get("agent", "")),
            )
            cols[1].metric("log2 fold-change", f"{top['log2fc']:.2f}")
        primary = (study.recall_cascade.get("all") or {}).get("at_k") or {}
        for i, k in enumerate(("recall@20", "recall@50")):
            w = (primary.get(k) or {}).get("wilson")
            if w:
                cols[2 + i].metric(
                    k,
                    f"{w['numerator']}/{w['denominator']}",
                    help=f"95% CI {w['low']:.2f}–{w['high']:.2f}; approved agents only",
                )

        st.info(
            "**A rank is only meaningful beside the size of the list it sits in.** The "
            f"shortlist here is around {study.recall_cascade.get('all', {}).get('median_shortlist_size', '—')} "
            "candidates, drawn from a surfaceome of "
            f"{study.surfaceome_size:,} accessions. Every rate below carries its "
            "numerator, denominator and interval, so you can disagree with the "
            "denominator and recompute.",
            icon="ℹ️",
        )

        counts = study.outcome_counts or {}
        if counts:
            st.markdown(
                "**Four outcomes, never merged into one rate.** An antigen the "
                "surfaceome reference does not contain, one a stated filter excluded, "
                "one the ranking placed low, and one whose lookup failed are four "
                "different findings about four different parts of the system."
            )
            oc = st.columns(4)
            labels = (
                ("ranked", "reached the shortlist"),
                ("gated_out", "excluded by a filter"),
                ("not_reachable", "outside the instrument"),
                ("infrastructure", "invalid, must re-run"),
            )
            for col, (key, label) in zip(oc, labels, strict=False):
                col.metric(label, counts.get(key, 0))

        table = pd.DataFrame(study.rows())
        for numeric_col in ("log2fc", "padj"):
            table[numeric_col] = pd.to_numeric(table[numeric_col], errors="coerce")
        # Rank and shortlist read as one cell: a rank alone is not interpretable.
        table["rank"] = [
            "—" if pd.isna(r) else f"{int(r)} of {int(sh)}"
            for r, sh in zip(table["rank"], table["shortlist"], strict=True)
        ]
        table["counterfactual"] = [
            "—" if pd.isna(c) else f"{int(c)} of {int(e)}"
            for c, e in zip(table["counterfactual_rank"], table["eligible"], strict=True)
        ]
        table = table.drop(columns=["shortlist", "counterfactual_rank", "eligible"])
        st.dataframe(
            table,
            hide_index=True,
            width="stretch",
            column_config={
                "log2fc": st.column_config.NumberColumn(
                    format="%.2f", help="Measured tumour-vs-normal fold change in this cohort"
                ),
                "padj": st.column_config.NumberColumn(
                    format="%.2e",
                    help="Multiple-testing-adjusted p-value; smaller means stronger "
                    "evidence the change is real",
                ),
                "rank": st.column_config.TextColumn(
                    "rank", help="Position in the candidate shortlist, and its size"
                ),
                "counterfactual": st.column_config.TextColumn(
                    help="Where it would have ranked with every filter removed. A low "
                    "number means a filter excluded it; a high one means the ranking "
                    "placed it low."
                ),
                "outcome": st.column_config.TextColumn(help="Which of the four outcomes"),
                "why": st.column_config.TextColumn(width="large"),
            },
        )

        sensitivity = study.tier_sensitivity or {}
        if sensitivity.get("at_k"):
            with st.expander("Sensitivity to the regulatory tier"):
                st.markdown(
                    "The headline counts only antigens whose targeting agent is "
                    "approved. That excludes CA9 and GPC3, whose evidence is strong "
                    "and whose agents are simply not licensed yet. Widening the panel "
                    "is reported separately rather than folded into the headline, "
                    "because choosing a denominator after seeing the data is what made "
                    "the earlier study untrustworthy."
                )
                rows = [
                    {"cutoff": k, "surfaced": f"{v['numerator']}/{v['denominator']}"}
                    for k, v in sensitivity["at_k"].items()
                ]
                st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")

        if study.design.get("unreachable_note"):
            with st.expander("Antigens the instrument could not see"):
                st.markdown(study.design["unreachable_note"])

        if study.set_sizes:
            with st.expander("The sets every rank was computed over"):
                st.dataframe(
                    pd.DataFrame(
                        [
                            {"cohort": k.removeprefix("TCGA-"), **v}
                            for k, v in sorted(study.set_sizes.items())
                        ]
                    ),
                    hide_index=True,
                    width="stretch",
                )

        for key in ("surfaced_ranks", "outcome_classes"):
            if key in study.figures:
                st.image(str(study.figures[key]), width="stretch")

    # -- Designer benchmark ----------------------------------------------
    if designer is not None:
        st.markdown("## The binders it actually designed")
        # Never assert "not a simulation" for a mock benchmark. The committed
        # artifact is a real GPU run (is_mock=False), but guard the claim on the
        # flag so a mock benchmark could never be mislabelled as genuine. The
        # claim needs an affirmative, present ``False``: an artifact that does
        # not record its own provenance is unknown, and unknown is not real.
        if designer.is_mock is None:
            st.warning(
                f"⚠️ **Provenance unrecorded** — this benchmark artifact does not state "
                f"whether it came from a real GPU run or the mock backend, so these "
                f"numbers are unverified and must not be cited as GPU results. Backend "
                f"`{designer.backend}`, validator `{designer.validator}`, "
                f"bindsight `{designer.bindsight_version}`, {designer.generated_utc[:10]}.",
                icon="⚠️",
            )
        elif designer.is_mock:
            st.warning(
                f"⚠️ **Mock backend** — these are synthetic, structurally-shaped "
                f"numbers for orchestration/CI, **not** real GPU results. Backend "
                f"`{designer.backend}`, validator `{designer.validator}`, "
                f"bindsight `{designer.bindsight_version}`, {designer.generated_utc[:10]}.",
                icon="⚠️",
            )
        else:
            st.markdown(
                f"**Real GPU run**, not a simulation — backend `{designer.backend}`, "
                f"GPU `{designer.gpu}`, validator `{designer.validator}`, "
                f"bindsight `{designer.bindsight_version}`, {designer.generated_utc[:10]}."
            )
        if designer.targets:
            st.caption(f"Target: {designer.targets[0]}")

        best = designer.best
        cols = st.columns(4)
        cols[0].metric("Designs", designer.n_designs)
        if best is not None and best.iptm is not None:
            cols[1].metric("Best ipTM", f"{best.iptm:.2f}")
        if designer.success_rate is not None:
            cols[2].metric("Success @ ipTM 0.65", f"{designer.success_rate * 100:.0f}%")
        paes = [b.pae_interaction for b in designer.binders if b.pae_interaction is not None]
        if paes:
            cols[3].metric("Mean PAE-int", f"{sum(paes) / len(paes):.1f} Å")

        # -- 3D viewer ----------------------------------------------------
        with_struct = designer.with_structures()
        if with_struct:
            st.markdown("### The predicted complexes")
            st.markdown(
                f"<span class='pill' style='background:{theme.ACCENT}22;color:{theme.ACCENT}'>"
                "designed binder</span> docked against "
                f"<span class='pill'>target antigen</span> — the real Boltz-2 predicted "
                "structure behind each ipTM below.",
                unsafe_allow_html=True,
            )
            choice = st.selectbox(
                "Design",
                options=[b.binder_id for b in with_struct],
                format_func=lambda bid: (
                    f"{bid} — ipTM {next(b.iptm for b in with_struct if b.binder_id == bid):.3f}"
                ),
            )
            binder = next(b for b in with_struct if b.binder_id == choice)

            view_col, meta_col = st.columns([3, 1])
            with view_col:
                if binder.complex_cif is not None:
                    _render_complex(binder.complex_cif)
            with meta_col:
                if binder.iptm is not None:
                    st.metric("ipTM", f"{binder.iptm:.3f}")
                if binder.pae_interaction is not None:
                    st.metric(
                        "PAE-int",
                        f"{binder.pae_interaction:.1f} Å",
                        help="Predicted Aligned Error at the interface; lower is a more "
                        "confident predicted contact",
                    )
                dev = binder.developability.get("developability_score")
                if dev is not None:
                    st.metric("Developability", f"{dev:.2f}")
                if binder.target_uniprot:
                    st.caption(f"Target {binder.target_uniprot}")
                if binder.complex_cif is not None:
                    # The viewer needs 3Dmol.js from a CDN. Offering the file
                    # keeps the structure usable offline, behind a strict
                    # network policy, or in PyMOL / ChimeraX.
                    st.download_button(
                        "⬇  mmCIF",
                        data=binder.complex_cif.read_bytes(),
                        file_name=binder.complex_cif.name,
                        mime="chemical/x-cif",
                        width="stretch",
                    )
            seq = binder.sequence
            if seq:
                st.code(seq, language=None)
                st.caption(f"{len(seq)} aa · ProteinMPNN sequence · chain B in the structure above")
            st.caption(
                "The viewer loads 3Dmol.js from a CDN. If your network blocks it, download the "
                "mmCIF and open it in PyMOL, ChimeraX or NGL — it is the same file."
            )

        # -- Per-design table ---------------------------------------------
        st.markdown("### Every design, scored")
        table = pd.DataFrame(
            [
                {
                    "binder_id": b.binder_id,
                    "ipTM": b.iptm,
                    "PAE-int (Å)": b.pae_interaction,
                    "developability": b.developability.get("developability_score"),
                    "length": b.developability.get("length"),
                    "instability": b.developability.get("instability_index"),
                    "GRAVY": b.developability.get("gravy"),
                    "free Cys": b.developability.get("n_cys"),
                }
                for b in designer.scored
            ]
        )
        st.dataframe(
            table,
            hide_index=True,
            width="stretch",
            column_config={
                "ipTM": st.column_config.ProgressColumn(
                    min_value=0.0,
                    max_value=1.0,
                    format="%.3f",
                    help="Boltz-2 interface confidence; ≥0.65 counts as success",
                ),
                "developability": st.column_config.ProgressColumn(
                    min_value=0.0,
                    max_value=1.0,
                    format="%.2f",
                    help="Composite of ProtParam sequence-biophysics descriptors",
                ),
                "PAE-int (Å)": st.column_config.NumberColumn(
                    format="%.1f",
                    help="Predicted Aligned Error at the binder–target interface, in "
                    "ångströms; lower means a more reliable predicted contact",
                ),
                "instability": st.column_config.NumberColumn(
                    format="%.1f", help="ProtParam instability index; <40 predicts stable"
                ),
                "GRAVY": st.column_config.NumberColumn(
                    format="%.3f",
                    help="Grand average of hydropathy; near 0 is soluble, strongly "
                    "positive is hydrophobic (aggregation-prone)",
                ),
                "free Cys": st.column_config.NumberColumn(
                    help="Count of cysteines; an odd number flags a disulfide / "
                    "oxidation liability",
                ),
            },
        )

        # -- Sequence space ------------------------------------------------
        coords = [b for b in designer.binders if b.pc1 is not None and b.pc2 is not None]
        if coords:
            st.markdown("### Sequence space (ESM-2 → PCA)")
            st.markdown(
                "Each design's mean-pooled ESM-2 embedding projected to two dimensions — "
                "a *pre-GPU* triage that shows which designs cluster and which are outliers "
                "before spending compute on validation."
            )
            st.scatter_chart(
                pd.DataFrame(
                    {
                        "PC1": [b.pc1 for b in coords],
                        "PC2": [b.pc2 for b in coords],
                        "ipTM": [b.iptm for b in coords],
                    }
                ),
                x="PC1",
                y="PC2",
                color="ipTM",
                width="stretch",
            )

    st.markdown("---")
    st.markdown(
        f"Reproduce these numbers yourself: "
        f"[study]({theme.GITHUB_URL}/blob/main/benchmarks/study/RESULTS.md) · "
        f"[designer benchmark]({theme.GITHUB_URL}/blob/main/benchmarks/designer_benchmark/RESULTS.md)"
    )


def _persist_upload(uploaded: Any, out_dir: Path, stem: str) -> Path:
    """Write a Streamlit upload to disk, preserving gzip compression.

    Streamlit hands us raw bytes and we choose the on-disk name. A gzipped
    counts matrix written under a plain ``.tsv`` name would be read by pandas as
    text and silently fail the DEG stage, so detect the gzip magic bytes (or a
    ``.gz`` name) and pick the extension accordingly; pandas'
    ``compression="infer"`` then reads it correctly.
    """
    data = uploaded.getvalue()
    name = (getattr(uploaded, "name", "") or "").lower()
    is_gzip = data[:2] == b"\x1f\x8b" or name.endswith(".gz")
    path = out_dir / (f"{stem}.tsv.gz" if is_gzip else f"{stem}.tsv")
    path.write_bytes(data)
    return path


def _page_run() -> None:
    st.title("Run on your own data")
    st.markdown(
        "Upload your **counts** matrix (gene × sample, integer counts) and "
        "**sample design** TSV. The pipeline runs the discovery half end-to-end — "
        "pydeseq2 differential expression, gene → protein mapping and tractability "
        "from Open Targets, the SURFY surfaceome filter, safety screening and "
        "ranking — and produces a paper-style HTML report you can download.\n\n"
        "The gene → protein mapping needs the **live Open Targets API**, so this "
        "page needs network access. If Open Targets is unreachable the run falls "
        "back to a small bundled gene map that covers only a handful of well-known "
        "genes; the result is then flagged on screen as **not** genome-wide."
    )

    counts_file = st.file_uploader(
        "Counts matrix (TSV, gene_id × samples)",
        type=["tsv", "txt", "gz"],
        help="First column is gene_id (Ensembl ENSG…), other columns are sample IDs. "
        "Plain or gzip-compressed (.tsv.gz) both work.",
    )
    design_file = st.file_uploader(
        "Sample design (TSV, sample × factors)",
        type=["tsv", "txt", "gz"],
        help="First column is sample (must match counts column names), then a 'condition' column.",
    )

    contrast_factor = st.text_input("Contrast factor", "condition")
    contrast_num = st.text_input("Contrast: numerator level (e.g. 'tumor')", "tumor")
    contrast_den = st.text_input("Contrast: denominator level (e.g. 'normal')", "normal")
    fdr = st.number_input("FDR threshold", 0.001, 1.0, 0.05, step=0.01)
    log2fc = st.number_input("|log2FC| threshold", 0.0, 10.0, 1.0, step=0.1)
    top_n = st.number_input("Top-N targets", 1, 20, 5)

    if st.button("▶  Run pipeline", type="primary", width="stretch"):
        if not (counts_file and design_file):
            st.error("Please upload both files.")
            return

        out_dir = Path(tempfile.mkdtemp(prefix="bindsight_user_")) / "run"
        out_dir.mkdir(parents=True, exist_ok=True)

        # Persist uploads to disk so the pipeline can read them with pandas,
        # preserving gzip compression so a .tsv.gz upload isn't misread as text.
        counts_path = _persist_upload(counts_file, out_dir, "counts")
        design_path = _persist_upload(design_file, out_dir, "design")

        from bindsight.config import (
            DEGParams,
            InputsConfig,
            RunConfig,
            StageParams,
            TargetDiscoveryParams,
        )

        cfg = RunConfig(
            name="user_run",
            out_dir=out_dir,
            inputs=InputsConfig(counts=counts_path, design=design_path),
            params=StageParams(
                deg=DEGParams(
                    design_formula=f"~ {contrast_factor}",
                    contrast=[contrast_factor, contrast_num, contrast_den],
                    fdr_threshold=float(fdr),
                    log2fc_threshold=float(log2fc),
                    min_replicates=2,
                    min_count=0,
                ),
                target_discovery=TargetDiscoveryParams(
                    surfy_allow_offline_fallback=True,
                    # Open Targets is the only genome-wide Ensembl → UniProt
                    # source. Without it the run can only ever map the handful of
                    # genes in the bundled offline table, so a stranger's cohort
                    # would yield a "discovery" drawn from a fixed shortlist.
                    # _render_open_targets_warning reports it when it degrades.
                    use_open_targets=True,
                    require_tractable_modality=[],
                    max_safety_events=1000,
                    require_surface_bind_site=False,
                    top_n=int(top_n),
                ),
            ),
        )

        with st.spinner("Running pipeline (typically 30 s – 2 min)…"):
            try:
                from bindsight.pipelines import discover as discover_pipeline

                t0 = time.time()
                manifest = discover_pipeline.run(cfg, out_dir=out_dir)
                elapsed = time.time() - t0
            except Exception as e:  # surface anything as a calm message
                _render_pipeline_error(e, context="run")
                return

        from bindsight.report import render_run

        report_path = render_run(out_dir)
        st.session_state[_RUN_RESULT_KEY] = (out_dir, manifest, elapsed, report_path)

    stashed = st.session_state.get(_RUN_RESULT_KEY)
    if stashed is not None:
        out_dir, manifest, elapsed, report_path = stashed
        # A stage can fail *without* raising (e.g. DESeq2 rejects the upload):
        # discover.run() marks the stage failed and returns. Guard against
        # presenting that broken run as a successful, empty result.
        if _render_stage_failures(manifest):
            return
        st.success(f"Pipeline complete in {elapsed:.1f} seconds.")
        _show_run_summary(out_dir, manifest, report_path)


def _discover_local_runs(limit: int = 25) -> list[Path]:
    """Find run directories on this machine, newest first.

    A run directory is identified by its provenance manifest, which every
    front-end writes (``pipelines/discover.run`` and the Snakemake assembler
    alike). Looks under the conventional ``runs/`` tree beside the working
    directory and the repository root.

    Args:
        limit: Maximum number of runs to return.

    Returns:
        Paths to run directories, most recently modified first.
    """
    seen: dict[Path, float] = {}
    for base in {Path.cwd() / "runs", _find_repo_root() / "runs"}:
        if not base.is_dir():
            continue
        for manifest in base.glob("**/run_manifest.jsonld"):
            run_dir = manifest.parent
            try:
                seen[run_dir] = manifest.stat().st_mtime
            except OSError:  # pragma: no cover - race with a concurrent run
                continue
    return sorted(seen, key=lambda p: seen[p], reverse=True)[:limit]


def _page_browse() -> None:
    st.title("Browse a run")
    st.markdown(
        "Inspect the outputs of any directory produced by `bindsight discover`, "
        "`bindsight run` or `bindsight demo`."
    )

    # The hosted deployments have no user-visible filesystem, so a bare path box
    # was unusable there. Offer whatever runs exist locally first.
    local = _discover_local_runs()
    run_dir: Path | None = None
    if local:
        pick = st.selectbox(
            "Runs found on this machine",
            options=["—"] + [str(p) for p in local],
            help="Directories under runs/ containing a provenance manifest.",
        )
        if pick != "—":
            run_dir = Path(pick)
    else:
        st.info(
            "No runs found under `runs/`. Run `bindsight demo` locally, or use the "
            "**Demo** page here, then come back.",
            icon="💡",
        )

    run_dir_str = st.text_input("…or enter a run directory path", "")
    if run_dir_str:
        run_dir = Path(run_dir_str)

    if run_dir is None:
        return
    if not run_dir.is_dir():
        st.error(f"Not a directory: {run_dir}")
        return
    # The manifest is the only record of whether the run finished, so a browsed
    # run is read from disk and routed through the same guard as a live one.
    manifest = _load_run_manifest(run_dir)
    if manifest is None:
        st.warning(
            "This directory has no readable `run_manifest.jsonld`, so there is nothing "
            "to confirm the run finished. Treat everything below as unverified — an "
            "empty table here may be a crash rather than a negative result.",
            icon="⚠️",
        )
    _show_run_summary(run_dir, manifest, report_path=run_dir / "report.html")


def _page_glossary() -> None:
    """A plain-English glossary of the domain terms the app uses.

    Rendered from :data:`theme.GLOSSARY`, the same source that generates the
    docs-site glossary, so the two never drift.
    """
    st.title("📖 Glossary")
    st.markdown(
        "Every specialist term bindsight uses, in plain language. If a word on "
        "another page is unfamiliar, it is almost certainly defined here."
    )
    st.info(theme.PLAIN_SUMMARY, icon="💡")
    for term, definition in theme.GLOSSARY:
        st.markdown(f"**{term}** — {definition}")


def _page_about() -> None:
    st.markdown(
        f"""
        # About bindsight

        bindsight is an open-source pipeline that takes RNA-seq counts and
        outputs ranked de novo protein binder candidates against
        differentially-expressed surface antigens. Every output is one click
        from its evidence chain — the patient cohort, the differential
        expression, the structure, the designer commit, the validator metrics.

        **License:** {theme.LICENSE_NAME} ·
        **Source:** [GitHub]({theme.GITHUB_URL}) ·
        **Cite:** [Zenodo DOI]({theme.ZENODO_DOI_URL})

        **Docs:** [What is bindsight?]({theme.docs_url("what-is-bindsight")}) ·
        [How to use]({theme.docs_url("how-to-use")}) ·
        [Use cases]({theme.docs_url("use-cases")}) ·
        [Designing on Colab]({theme.docs_url("colab-design-howto")})

        **Built on the shoulders of:** RFdiffusion (BSD-3), ProteinMPNN (MIT),
        BindCraft (MIT), BoltzGen (MIT), Boltz-2 (MIT), Chai-1r (Apache-2),
        SURFACE-Bind (BSD-3), Open Targets (CC0), AlphaFoldDB (CC BY 4.0),
        Snakemake (MIT). See `LICENSING.md` for the full per-component
        commercial-use audit.
        """
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _find_repo_root() -> Path:
    """Walk up from this file to find the repo root (where examples/ lives)."""
    here = Path(__file__).resolve()
    for parent in [here.parent, *here.parents]:
        if (parent / "examples" / "demo" / "config.yaml").exists():
            return parent
    # Fall back to CWD if we can't locate the repo.
    return Path.cwd()


#: ``open_targets_status`` written by ``pipelines.discover`` for a candidate whose
#: enrichment came from a live Open Targets record. Every other value means the
#: gene → UniProt mapping came from the bundled offline table instead.
_OT_STATUS_LIVE = "ok"


def _render_open_targets_warning(cand: Any) -> None:
    """Warn when candidates were mapped offline instead of through Open Targets.

    Open Targets is the only genome-wide Ensembl → UniProt source in the
    pipeline. When it is unreachable (or disabled), the only mapping left is the
    bundled table of a few well-known genes, and every gene missing from it is
    dropped before the surfaceome filter. The resulting shortlist is drawn from
    that fixed handful, not from the cohort, so it must not be read as a
    genome-wide discovery — and an absence from it means nothing at all.

    Args:
        cand: The candidates table, or ``None`` when the run produced none.
    """
    if cand is None or "open_targets_status" not in getattr(cand, "columns", ()):
        return
    statuses = [str(s) for s in cand["open_targets_status"]]
    degraded = [s for s in statuses if s != _OT_STATUS_LIVE]
    if not degraded:
        return
    breakdown = ", ".join(f"`{s}` × {degraded.count(s)}" for s in dict.fromkeys(degraded))
    lead = (
        f"**{len(degraded)} of {len(statuses)} candidates were mapped from the bundled "
        f"offline gene table, not from a live Open Targets record** ({breakdown})."
    )
    if len(degraded) == len(statuses):
        # Nothing came back live, so the bundled table was the entire mapping.
        tail = (
            " Open Targets answered for none of them, so that table's handful of "
            "well-known genes was the only gene → protein mapping available and every "
            "other gene in this cohort was dropped before the surfaceome filter. "
            "**This is not a genome-wide discovery**: a gene's absence from it is no "
            "evidence about that gene."
        )
    else:
        tail = (
            " Open Targets answered for the rest, so the genes it failed on were dropped "
            "before the surfaceome filter unless that table happened to list them. "
            "**This shortlist is incomplete.**"
        )
    st.warning(f"{lead}{tail} Re-run with Open Targets reachable for a full discovery.", icon="⚠️")


def _show_run_summary(run_dir: Path, manifest: Any, report_path: Path | None) -> None:
    """Render KPIs, tables, and inline-report-iframe for a finished run."""
    # Last line of defence for every caller: a manifest recording a failed stage
    # must never reach the success layout, where "0 candidates" would read as a
    # measured negative rather than as a crash.
    if _render_stage_failures(manifest):
        return

    candidates_p = run_dir / "targets" / "candidates.parquet"
    epitopes_p = run_dir / "epitopes" / "epitopes.parquet"
    deg_p = run_dir / "deg" / "results.parquet"

    # Cached parquet reads (see @st.cache_data on _load_parquet_cached) keep
    # repeat visits to the same run free of disk I/O and pandas re-allocation.
    cand = _load_parquet_cached(str(candidates_p))
    epi = _load_parquet_cached(str(epitopes_p))
    deg = _load_parquet_cached(str(deg_p))

    cols = st.columns(4)
    cols[0].metric("Genes tested", len(deg) if deg is not None else 0)
    cols[1].metric(
        "Significant DEGs",
        int(deg["significant"].sum()) if deg is not None and "significant" in deg.columns else 0,
    )
    cols[2].metric("Candidates", len(cand) if cand is not None else 0)
    cols[3].metric("Top-N epitopes", len(epi) if epi is not None else 0)

    _render_open_targets_warning(cand)

    if cand is not None and not cand.empty:
        st.markdown("### Ranked target candidates")
        cols_to_show = [
            c
            for c in (
                "rank",
                "symbol",
                "uniprot_id",
                "log2fc",
                "padj",
                "tractable_modalities",
                "n_safety_events",
                "has_alphafold_structure",
                "rank_in_top_n",
            )
            if c in cand.columns
        ]
        st.dataframe(cand[cols_to_show], hide_index=True, width="stretch")

        # Download buttons
        st.download_button(
            "⬇  Download candidates.parquet",
            data=candidates_p.read_bytes(),
            file_name="candidates.parquet",
            mime="application/x-parquet",
        )

    if report_path and report_path.exists():
        st.markdown("### Report")
        st.download_button(
            "⬇  Download report.html",
            data=report_path.read_bytes(),
            file_name="report.html",
            mime="text/html",
        )
        # Embed inline so the user sees it without leaving the app. st.iframe
        # supersedes the deprecated components.v1.html; the report HTML is
        # produced by our own renderer, not user input. Skipped under the test
        # harness for the same reason as the 3-D viewer (see _under_app_test).
        with st.expander("Open the rendered report inline", expanded=True):
            if not _under_app_test():
                st.iframe(
                    report_path.read_text(encoding="utf-8"),
                    height=900,
                )

    manifest_p = run_dir / "run_manifest.jsonld"
    if manifest_p.exists():
        with st.expander("Provenance manifest (PROV-O JSON-LD)"):
            data = json.loads(manifest_p.read_text(encoding="utf-8"))
            data.pop("@context", None)
            st.json(data)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main() -> None:
    """Streamlit page-router entry point."""
    if st is None:  # pragma: no cover
        print('Streamlit not installed. Run: pip install -e ".[report]"', file=sys.stderr)
        sys.exit(1)

    st.set_page_config(
        page_title=theme.PAGE_TITLE,
        layout=theme.PAGE_LAYOUT,
        page_icon=theme.PAGE_ICON,
        # "auto" = expanded on desktop, collapsed on phones. Forcing it open
        # puts the sidebar overlay on top of the hero on a phone, hiding the
        # pitch behind a panel the visitor has to dismiss. Mobile navigation is
        # instead solved on the page itself: the Home call-to-action buttons
        # reach Real results / Demo / Run without touching the sidebar.
        initial_sidebar_state="auto",
    )
    _inject_css()

    # Apply any cross-page navigation requested by a button on the previous run.
    # This must happen before the radio is instantiated.
    pending = st.session_state.pop(_NAV_PENDING_KEY, None)
    if pending is not None:
        st.session_state[_NAV_KEY] = pending

    page = st.sidebar.radio(
        "Navigation",
        options=(
            "🏠 Home",
            "🔬 Real results",
            "✨ Demo",
            "📤 Run on my data",
            "🔎 Browse a run",
            "📖 Glossary",
            "ℹ️ About",
        ),
        label_visibility="collapsed",
        key=_NAV_KEY,
    )
    st.sidebar.markdown("---")
    st.sidebar.markdown(
        f'<span class="small-muted">bindsight · {theme.LICENSE_NAME} · '
        f'<a href="{theme.GITHUB_URL}">GitHub</a> · '
        f'<a href="{theme.DOCS_URL}">Docs</a></span>',
        unsafe_allow_html=True,
    )

    if page.startswith("🏠"):
        _page_home()
    elif page.startswith("🔬"):
        _page_results()
    elif page.startswith("✨"):
        _page_demo()
    elif page.startswith("📤"):
        _page_run()
    elif page.startswith("🔎"):
        _page_browse()
    elif page.startswith("📖"):
        _page_glossary()
    else:
        _page_about()


if __name__ == "__main__":
    main()
